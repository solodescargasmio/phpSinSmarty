-- Dump de la Base de Datos
-- Fecha: martes 10 mayo 2016 - 21:29:07
--
-- Version: 1.1.1, del 18 de Marzo de 2005, insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `phpfinal`
-- ------------------------------------------------------
-- Server version	5.5.36

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS administrador;
CREATE TABLE `administrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `tipo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick` (`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrador`
--

LOCK TABLES administrador WRITE;
INSERT INTO administrador VALUES('1', 'admin', 'Ad', 'Min', 'micorreo@outlook.com', 'd033e22ae348aeb5660fc2140aec35850c4da997', '0');
UNLOCK TABLES;


--
-- Table structure for table `atributo`
--

DROP TABLE IF EXISTS atributo;
CREATE TABLE `atributo` (
  `id_attributo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `calculado` tinyint(1) NOT NULL,
  `tabla` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_attributo`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `atributo`
--

LOCK TABLES atributo WRITE;
INSERT INTO atributo VALUES('1', 'id_paciente', 'int', '0', '0');
INSERT INTO atributo VALUES('2', 'nombre', 'text', '0', '0');
INSERT INTO atributo VALUES('3', 'apellido', 'text', '0', '0');
INSERT INTO atributo VALUES('4', 'fecha_nac', 'date', '0', '0');
INSERT INTO atributo VALUES('5', 'edad', 'int', '1', '0');
INSERT INTO atributo VALUES('6', 'sexo', 'text', '0', '1');
INSERT INTO atributo VALUES('7', 'peso', 'double', '0', '0');
INSERT INTO atributo VALUES('8', 'altura', 'double', '0', '0');
INSERT INTO atributo VALUES('9', 'fecha_estudio', 'date', '0', '0');
INSERT INTO atributo VALUES('10', 'imc', 'double', '1', '0');
INSERT INTO atributo VALUES('11', 'titulo', 'text', '0', '0');
INSERT INTO atributo VALUES('12', 'texto', 'text', '0', '0');
INSERT INTO atributo VALUES('13', 'car_fem', 'int', '0', '0');
INSERT INTO atributo VALUES('14', 'car_hueco', 'int', '0', '0');
INSERT INTO atributo VALUES('15', 'hueco_hombro', 'int', '0', '0');
INSERT INTO atributo VALUES('16', 'hombro_braq', 'int', '0', '0');
INSERT INTO atributo VALUES('17', 'hombro_rad', 'int', '0', '0');
INSERT INTO atributo VALUES('18', 'hueco_cuffxell', 'int', '0', '0');
INSERT INTO atributo VALUES('19', 'cuffxell_fem', 'int', '0', '0');
INSERT INTO atributo VALUES('20', 'cd', 'double', '0', '0');
INSERT INTO atributo VALUES('21', 'ci', 'double', '0', '0');
INSERT INTO atributo VALUES('22', 'psis', 'int', '0', '0');
INSERT INTO atributo VALUES('23', 'pdias', 'int', '0', '0');
INSERT INTO atributo VALUES('24', 'psis', 'int', '0', '0');
INSERT INTO atributo VALUES('25', 'pdias', 'int', '0', '0');
INSERT INTO atributo VALUES('26', 'fuma', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('27', 'presion', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('28', 'colesterol', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('29', 'hiperglisemia', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('30', 'ant_familiares', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('31', 'sedentarismo', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('32', 'ejercicio', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('33', 'medicacion', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('34', 'diabetes', 'checkbox', '0', '0');
INSERT INTO atributo VALUES('35', 'hemo', 'float', '0', '0');
INSERT INTO atributo VALUES('36', 'xcell', 'float', '0', '0');
UNLOCK TABLES;


--
-- Table structure for table `dependencia`
--

DROP TABLE IF EXISTS dependencia;
CREATE TABLE `dependencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `depende` varchar(100) NOT NULL,
  `de` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dependencia`
--

LOCK TABLES dependencia WRITE;
UNLOCK TABLES;


--
-- Table structure for table `estudio_atributo`
--

DROP TABLE IF EXISTS estudio_atributo;
CREATE TABLE `estudio_atributo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_estudio` int(11) NOT NULL,
  `id_form` int(11) NOT NULL,
  `id_attributo` int(11) NOT NULL,
  `valor` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_estudio` (`id_estudio`),
  CONSTRAINT `estudio_atributo_ibfk_1` FOREIGN KEY (`id_estudio`) REFERENCES `estudio_paciente` (`id_estudio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `estudio_atributo`
--

LOCK TABLES estudio_atributo WRITE;
UNLOCK TABLES;


--
-- Table structure for table `estudio_paciente`
--

DROP TABLE IF EXISTS estudio_paciente;
CREATE TABLE `estudio_paciente` (
  `id_estudio` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `fecha_estudio` date NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id_estudio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `estudio_paciente`
--

LOCK TABLES estudio_paciente WRITE;
UNLOCK TABLES;


--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS form;
CREATE TABLE `form` (
  `id_form` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `version` int(11) NOT NULL,
  `fecha_crea` date NOT NULL,
  PRIMARY KEY (`id_form`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `form`
--

LOCK TABLES form WRITE;
INSERT INTO form VALUES('1', 'paciente', '1', '2016-05-09');
INSERT INTO form VALUES('2', 'ficha_patronimica', '1', '2016-05-09');
INSERT INTO form VALUES('3', 'comentario', '1', '2016-05-09');
INSERT INTO form VALUES('4', 'distancia', '1', '2016-05-09');
INSERT INTO form VALUES('5', 'imt', '1', '2016-05-09');
INSERT INTO form VALUES('6', 'presion_braqueal', '1', '2016-05-09');
INSERT INTO form VALUES('7', 'presion_central', '1', '2016-05-09');
INSERT INTO form VALUES('8', 'riesgo', '1', '2016-05-09');
INSERT INTO form VALUES('9', 'vop', '1', '2016-05-09');
UNLOCK TABLES;


--
-- Table structure for table `form_attr`
--

DROP TABLE IF EXISTS form_attr;
CREATE TABLE `form_attr` (
  `id_form` int(11) NOT NULL,
  `id_attributo` int(11) NOT NULL,
  `obligatorio` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_form`,`id_attributo`),
  KEY `id_form` (`id_form`,`id_attributo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `form_attr`
--

LOCK TABLES form_attr WRITE;
INSERT INTO form_attr VALUES('1', '1', '1');
INSERT INTO form_attr VALUES('1', '2', '1');
INSERT INTO form_attr VALUES('1', '3', '1');
INSERT INTO form_attr VALUES('1', '4', '1');
INSERT INTO form_attr VALUES('1', '5', '1');
INSERT INTO form_attr VALUES('1', '6', '1');
INSERT INTO form_attr VALUES('2', '1', '1');
INSERT INTO form_attr VALUES('2', '7', '1');
INSERT INTO form_attr VALUES('2', '8', '1');
INSERT INTO form_attr VALUES('2', '9', '1');
INSERT INTO form_attr VALUES('2', '10', '1');
INSERT INTO form_attr VALUES('3', '1', '1');
INSERT INTO form_attr VALUES('3', '11', '1');
INSERT INTO form_attr VALUES('3', '12', '1');
INSERT INTO form_attr VALUES('4', '1', '1');
INSERT INTO form_attr VALUES('4', '13', '1');
INSERT INTO form_attr VALUES('4', '14', '1');
INSERT INTO form_attr VALUES('4', '15', '1');
INSERT INTO form_attr VALUES('4', '16', '1');
INSERT INTO form_attr VALUES('4', '17', '1');
INSERT INTO form_attr VALUES('4', '18', '1');
INSERT INTO form_attr VALUES('4', '19', '1');
INSERT INTO form_attr VALUES('5', '1', '1');
INSERT INTO form_attr VALUES('5', '20', '1');
INSERT INTO form_attr VALUES('5', '21', '1');
INSERT INTO form_attr VALUES('6', '1', '1');
INSERT INTO form_attr VALUES('6', '22', '1');
INSERT INTO form_attr VALUES('6', '23', '1');
INSERT INTO form_attr VALUES('7', '1', '1');
INSERT INTO form_attr VALUES('7', '24', '1');
INSERT INTO form_attr VALUES('7', '25', '1');
INSERT INTO form_attr VALUES('8', '1', '1');
INSERT INTO form_attr VALUES('8', '26', '1');
INSERT INTO form_attr VALUES('8', '27', '1');
INSERT INTO form_attr VALUES('8', '28', '1');
INSERT INTO form_attr VALUES('8', '29', '1');
INSERT INTO form_attr VALUES('8', '30', '1');
INSERT INTO form_attr VALUES('8', '31', '1');
INSERT INTO form_attr VALUES('8', '32', '1');
INSERT INTO form_attr VALUES('8', '33', '1');
INSERT INTO form_attr VALUES('8', '34', '1');
INSERT INTO form_attr VALUES('9', '1', '1');
INSERT INTO form_attr VALUES('9', '35', '1');
INSERT INTO form_attr VALUES('9', '36', '1');
INSERT INTO form_attr VALUES('10', '1', '1');
INSERT INTO form_attr VALUES('10', '12', '1');
INSERT INTO form_attr VALUES('10', '20', '1');
INSERT INTO form_attr VALUES('10', '21', '1');
INSERT INTO form_attr VALUES('11', '1', '1');
INSERT INTO form_attr VALUES('11', '35', '1');
INSERT INTO form_attr VALUES('11', '36', '1');
INSERT INTO form_attr VALUES('11', '37', '1');
INSERT INTO form_attr VALUES('12', '1', '1');
INSERT INTO form_attr VALUES('12', '20', '1');
INSERT INTO form_attr VALUES('12', '21', '1');
INSERT INTO form_attr VALUES('12', '37', '1');
UNLOCK TABLES;


--
-- Table structure for table `tabla`
--

DROP TABLE IF EXISTS tabla;
CREATE TABLE `tabla` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_attributo` int(11) NOT NULL,
  `opcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_attributo` (`id_attributo`),
  CONSTRAINT `tabla_ibfk_1` FOREIGN KEY (`id_attributo`) REFERENCES `atributo` (`id_attributo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tabla`
--

LOCK TABLES tabla WRITE;
INSERT INTO tabla VALUES('1', '6', 'femenino');
INSERT INTO tabla VALUES('2', '6', 'masculino');
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.